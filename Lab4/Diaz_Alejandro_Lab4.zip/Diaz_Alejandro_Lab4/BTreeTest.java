import java.util.Random; 
public class BTreeTest{
 
  public static void printAscending(BTreeNode T){
   //Prints all keys in the tree in ascending order
		if (T.isLeaf){
			for(int i =0; i<T.n;i++)
				System.out.print(T.key[i]+" ");
		}
		else{
			for(int i =0; i<T.n;i++){
				printAscending(T.c[i]);
				System.out.print(T.key[i]+" ");
			}
			printAscending(T.c[T.n]);

		}
   }

   public static void main(String[] args)   {
	   int [] S ={6, 6, 3, 16, 11, 7, 17, 14, 3, 8, 5, 19, 15, 1, 2, 4, 3, 18, 13, 9, 20, 10, 12, 21, 22};

		BTree B = new BTree(3);
      for (int i=0;i<S.length;i++){
  			B.insert(S[i]);
		    B.printNodes();
        System.out.println("*********************");
      }

      B.printNumKeys();
      B.printNumNodes();
      System.out.println(B.root.c[1].findKeyBinary(17));

      
      BTreeNode T = B.root;
      printAscending(T);
      B.printDescendingAtDepth(T, 1);
      System.out.println();
      System.out.println(B.findKey(T, 23));
      System.out.println(B.getMinAtDepth(T, 0));
      System.out.println(B.getMaxAtDepth(T, 0));
      System.out.println(B.getNumKeysAtDepth(T, 2));
      System.out.println(B.getKeysSum(T));
      System.out.println(B.getKeysSumAtDepth(T,2));
      System.out.println(B.getNumNodes(T));
      System.out.println(B.getNumLeaves(T));
      System.out.println(B.getNumNodesFull(T));
      System.out.println(B.getKeyDepth(T, 23));
      B.printKeysInNode(T,18);
      System.out.println();
      

      
      //Build B-tree with random elements
      Random rn = new Random();
      BTree R = new BTree(4);
      for (int i=0;i<30;i++){
  			R.insert(rn.nextInt(100));
		   R.printNodes();
         System.out.println("*********************");
      }
      T = R.root;


      printAscending(T);
      System.out.println();
      R.printDescendingAtDepth(T, 1);
      System.out.println();
      System.out.println(R.findKey(T, 23));
      System.out.println(R.getMinAtDepth(T, 1));
      System.out.println(R.getMaxAtDepth(T, 1));
      System.out.println(R.getNumKeysAtDepth(T, 1));
      System.out.println(R.getKeysSum(T));
      System.out.println(R.getKeysSumAtDepth(T,1));
      System.out.println(R.getNumNodes(T));
      System.out.println(R.getNumLeaves(T));
      System.out.println(R.getNumNodesFull(T));
      System.out.println(R.getKeyDepth(T, 23));
      B.printKeysInNode(T,18);
      System.out.println();
      
	}
}